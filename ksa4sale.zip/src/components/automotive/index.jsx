import React from "react";

const Automotive = () => {
  return <div>i am Automotive Design here</div>;
};

export default Automotive;
