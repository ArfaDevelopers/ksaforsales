const categories = [
  {
    id: 1,
    title: "Cars",
    image:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRq9FsDn0pGVm8ay0WCMuDsv98Xf56FAhFg3Q&s",
    phone: "+96541117775",
  },
  {
    id: 2,
    title: "Jobs",
    image:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTP60u2MUASTzHB83NhmYT0-CN_b4aS55fzhw&s",
    phone: "+96552223344",
  },
  {
    id: 3,
    title: "Real Estate for Rent",
    image:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ5KZCLqXG6DjZjCiOEndJcnXLqu6e-KafZjg&s",
    phone: "+96563334455",
  },
  {
    id: 4,
    title: "Electronics",
    image:
      "https://vidico.com/app/uploads/2024/04/Best-Commercial-Ads-to-Inspire-Your-Marketing-1.webp",
    phone: "+96541117775",
  },
  {
    id: 5,
    title: "Furniture",
    image:
      "https://i0.wp.com/www.superbowl-ads.com/wp-content/uploads/2021/01/usatoday_admeter2021.png?fit=1920%2C1080&ssl=1",
    phone: "+96541117775",
  },
  {
    id: 6,
    title: "Fashion",
    image: "https://i.ytimg.com/vi/Tx2DPYeVngw/maxresdefault.jpg",
    phone: "+96541117775",
  },
  {
    id: 7,
    title: "Sports",
    image:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR_J0RV_96GQjtxnPbfCFRCyNY4bg11sbHM0g&s",
    phone: "+96541117775",
  },
  {
    id: 8,
    title: "Home & Garden",
    image:
      "https://i.ytimg.com/vi/CebzjiESbXc/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLBsYv5jhw86iScAgxYmyedNeSwfog",
    phone: "+96541117775",
  },
];

export default categories;
